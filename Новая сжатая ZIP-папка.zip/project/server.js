const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Статические файлы
app.use(express.static(path.join(__dirname, 'public')));

// Хранение пользователей
const users = new Map();

io.on('connection', (socket) => {
    console.log('Новый пользователь подключился:', socket.id);

    // Обработка входа пользователя
    socket.on('user-join', (username) => {
        users.set(socket.id, {
            id: socket.id,
            username: username,
            joinTime: new Date()
        });

        // Уведомляем всех о новом пользователе
        socket.broadcast.emit('user-joined', {
            username: username,
            message: `${username} присоединился к чату`,
            timestamp: new Date()
        });

        // Отправляем текущий список пользователей
        io.emit('users-update', Array.from(users.values()));
    });

    // Обработка сообщений
    socket.on('send-message', (data) => {
        const user = users.get(socket.id);
        if (user) {
            const messageData = {
                username: user.username,
                message: data.message,
                timestamp: new Date(),
                userId: socket.id
            };
            
            // Отправляем сообщение всем пользователям
            io.emit('receive-message', messageData);
        }
    });

    // Обработка отключения
    socket.on('disconnect', () => {
        const user = users.get(socket.id);
        if (user) {
            users.delete(socket.id);
            
            // Уведомляем о выходе пользователя
            socket.broadcast.emit('user-left', {
                username: user.username,
                message: `${user.username} покинул чат`,
                timestamp: new Date()
            });

            // Обновляем список пользователей
            io.emit('users-update', Array.from(users.values()));
        }
        console.log('Пользователь отключился:', socket.id);
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Сервер запущен на порту ${PORT}`);
});